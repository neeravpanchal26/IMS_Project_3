create procedure uspInspectEquipmentBySerial(IN serial varchar(24))
  BEGIN
    SELECT EquipmentID INTO @id FROM equipment WHERE equipment.Serial = serial;
    SELECT equipmentID,eh.`Desc`,@max :=MAX(e.times) AS maxDate,eh.Condition,eh.Value
    FROM equipmenthistory AS eh, ( SELECT equipmenthistory.Date AS times FROM equipmenthistory WHERE equipmenthistory.equipmentID = @id ) AS e
    WHERE eh.equipmentID = @id AND eh.AllocationType = 2 AND eh.Date = @max
    GROUP BY equipmentID;
  END;

