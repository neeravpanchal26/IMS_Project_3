create procedure uspInspectEquipmentByID(IN ID int)
  BEGIN
  SELECT e.Name,e.Serial,eh.`Desc`
  FROM equipment AS e,equipmenthistory AS eh
  WHERE e.EquipmentID = eh.equipmentID AND
        eh.AllocationType = 2 AND
    eh.userID = ID;
END;

