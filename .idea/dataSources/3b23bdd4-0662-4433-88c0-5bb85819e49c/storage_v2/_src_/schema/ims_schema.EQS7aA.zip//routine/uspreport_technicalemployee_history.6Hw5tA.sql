create procedure uspReport_TechnicalEmployee_History(IN sDate      date, IN eDate date, IN aType varchar(45),
                                                     IN eCondition varchar(45), IN uID int)
  BEGIN
    SELECT e.EquipmentID, e.Name, eh.`Desc`, eh.Value, eh.Date, c.ConditionDesc, a.TypeDesc, eh.Active
    FROM equipment AS e,
         equipmenthistory AS eh,
         `condition` AS c,
         allocationtype AS a
    WHERE e.EquipmentID = eh.equipmentID
      AND eh.`Condition` = c.ConditionID
      AND eh.AllocationType = a.TypeID
      AND eh.userID = uID
      AND a.TypeDesc LIKE CONCAT(aType, '%')
      AND c.ConditionDesc LIKE CONCAT(eCondition, '%')
      AND eh.Date BETWEEN sDate AND eDate;
  END;

