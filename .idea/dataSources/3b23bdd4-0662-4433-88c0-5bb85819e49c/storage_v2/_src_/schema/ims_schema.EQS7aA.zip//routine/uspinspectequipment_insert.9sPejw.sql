create procedure uspInspectEquipment_Insert(IN userID  int, IN eSerial varchar(24), IN eCondition int,
                                            IN eValue  decimal, IN eActive bit, IN eDesc varchar(100))
  BEGIN
    DECLARE errno INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
      GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
      SELECT errno AS MYSQL_ERROR;
      ROLLBACK;
    END;

    START TRANSACTION;
    SET autocommit = 0;
    SELECT e.EquipmentID INTO @ID FROM equipment AS e WHERE e.Serial = eSerial;

    INSERT INTO equipmenthistory (Date,
                                  `Condition`,
                                  Picture,
                                  Value,
                                  equipmentID,
                                  userID,
                                  Active,
                                  `Desc`,
                                  AllocationType)
    VALUES (CURRENT_DATE(), eCondition, null, eValue, @ID, userID, eActive, eDesc, 2);

    UPDATE equipment AS e
    SET e.EquipmentCondition = eCondition,
        e.Cost               = eValue;
    COMMIT WORK;
  END;

