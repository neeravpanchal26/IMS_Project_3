create procedure uspUserSetting_Suburbs()
  BEGIN
SELECT s.SuburbID,s.suburbName
FROM suburb AS s;
END;

