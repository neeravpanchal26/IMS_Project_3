create procedure uspMaintainEquipment_InsertImage(IN image longblob, IN equipSerial varchar(24))
  BEGIN
    SELECT EquipmentID INTO @id FROM equipment WHERE equipment.Serial = equipSerial;
    SELECT MAX(equipmenthistory.Date) INTO @dMax FROM equipmenthistory WHERE equipmenthistory.equipmentID = @id AND equipmenthistory.AllocationType = 3;
    UPDATE equipmenthistory SET equipmenthistory.Picture = image WHERE equipmenthistory.equipmentID = @id AND equipmenthistory.Date = @dMax;
    UPDATE equipment SET equipment.ConditionPicture = image WHERE equipment.EquipmentID = @id;
  END;

