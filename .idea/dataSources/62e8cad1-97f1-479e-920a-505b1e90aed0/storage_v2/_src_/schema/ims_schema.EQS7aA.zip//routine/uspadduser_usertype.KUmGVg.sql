create procedure uspAddUser_UserType()
  BEGIN
SELECT *
FROM usertype;
END;

