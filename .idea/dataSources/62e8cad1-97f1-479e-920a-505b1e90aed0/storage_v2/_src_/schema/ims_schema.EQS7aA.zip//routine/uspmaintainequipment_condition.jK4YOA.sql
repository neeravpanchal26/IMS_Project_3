create procedure uspMaintainEquipment_Condition()
  BEGIN
	SELECT *
    FROM `condition`;
END;

