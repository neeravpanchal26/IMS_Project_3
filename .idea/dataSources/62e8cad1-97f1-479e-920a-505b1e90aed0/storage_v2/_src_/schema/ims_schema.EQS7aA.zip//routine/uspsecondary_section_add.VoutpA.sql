create procedure uspSecondary_Section_Add(IN name varchar(45))
  BEGIN
  -- Error Handling
  DECLARE errno INT;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
    SELECT errno AS MYSQL_ERROR;
    ROLLBACK;
  END;

  START TRANSACTION;
  SET autocommit=0;

  SELECT MAX(section.SectionID)+1 INTO @sectionID FROM section;
  INSERT INTO section (SectionID, SectionDesc) VALUE (@sectionID,name);
  COMMIT WORK;
END;

