create procedure uspBusiness_Logo()
  BEGIN
	SELECT business.Logo
    FROM business
    WHERE business.BusinessID = 1;
END;

