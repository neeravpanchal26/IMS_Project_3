create procedure uspManageEquipment_GetEquipmentBySerial(IN serialNo varchar(50))
  BEGIN
SELECT `Name`, `Desc`
FROM equipment
where `Serial`=serialNo;

END;

