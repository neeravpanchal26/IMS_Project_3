create procedure uspDashboard_EquipmentHistoryUser(IN userID int, IN days int)
  BEGIN
    SELECT MAX(equipmenthistory.Date) as 'date', equipment.Name, equipment.`Desc`, equipmenthistory.Value
    FROM equipmenthistory,
         equipment
    WHERE equipment.Active = 1
      AND equipmenthistory.userID = userID
      AND equipmenthistory.Date between NOW() + INTERVAL - days DAY AND NOW() + INTERVAL  0 DAY
      AND equipmenthistory.equipmentID = equipment.EquipmentID;
  END;

