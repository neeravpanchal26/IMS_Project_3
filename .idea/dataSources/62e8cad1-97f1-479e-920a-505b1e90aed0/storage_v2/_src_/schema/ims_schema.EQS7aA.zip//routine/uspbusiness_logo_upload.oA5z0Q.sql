create procedure uspBusiness_Logo_Upload(IN logo longblob)
  BEGIN
    UPDATE business
    SET business.Logo = logo
    WHERE business.BusinessID = 1;
END;

