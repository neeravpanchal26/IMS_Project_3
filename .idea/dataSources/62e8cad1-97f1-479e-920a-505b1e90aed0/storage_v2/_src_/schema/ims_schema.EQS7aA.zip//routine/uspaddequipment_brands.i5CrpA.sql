create procedure uspAddEquipment_Brands()
  BEGIN
SELECT BrandID, BrandDesc
FROM brand
Order by BrandDesc;
END;

