create procedure uspBusiness()
  BEGIN
SELECT business.BusinessName,business.contact,business.Email
FROM business;
END;

