create procedure uspSecondary_Type_Add(IN name varchar(45))
  BEGIN
  -- Error Handling
  DECLARE errno INT;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
    SELECT errno AS MYSQL_ERROR;
    ROLLBACK;
  END;

  START TRANSACTION;
  SET autocommit=0;

  SELECT MAX(type.TypeID)+1 INTO @typeID FROM type;
  INSERT INTO type (TypeID, TypeDesc) VALUE (@typeID,name);
  COMMIT WORK;
END;

