create procedure uspSecondary_Suburb_Add(IN cityID int, IN suburbName varchar(45))
  BEGIN
	 -- Error Handling
	  DECLARE errno INT;
	  DECLARE EXIT HANDLER FOR SQLEXCEPTION
	  BEGIN
		GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
		SELECT errno AS MYSQL_ERROR;
		ROLLBACK;
	  END;

	  START TRANSACTION;
	  SET autocommit=0;
      
      SELECT MAX(suburbID)+1 INTO @id FROM suburb;
      INSERT INTO suburb (suburbID,suburbName,cityID) VALUE (@id,suburbName,cityID);
      COMMIT WORK;
END;

