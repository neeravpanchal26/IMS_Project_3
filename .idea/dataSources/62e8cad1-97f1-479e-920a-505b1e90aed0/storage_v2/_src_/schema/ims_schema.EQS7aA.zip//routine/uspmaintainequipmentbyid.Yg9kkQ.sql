create procedure uspMaintainEquipmentByID(IN ID int)
  BEGIN
  SELECT e.Name,e.Serial,eh.`Desc`
  FROM equipment AS e,equipmenthistory AS eh
  WHERE e.EquipmentID = eh.equipmentID AND
        eh.AllocationType = 3 AND
        eh.Active = 1 AND
    eh.userID = ID
    GROUP BY e.`Serial`;
END;

