create procedure uspBusiness_GroupPolicy()
  BEGIN
	SELECT business.GroupPolicy
    FROM business
    WHERE business.BusinessID = 1;
END;

