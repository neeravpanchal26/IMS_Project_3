create procedure uspAddEquipment_Status()
  BEGIN
SELECT StatusID, StatusDesc
FROM equipmentstatus
Order by StatusDesc;
END;

