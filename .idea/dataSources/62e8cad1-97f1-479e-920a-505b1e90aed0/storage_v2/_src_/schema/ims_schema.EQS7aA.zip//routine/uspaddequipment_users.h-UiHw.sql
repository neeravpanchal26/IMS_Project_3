create procedure uspAddEquipment_Users()
  SELECT CONCAT(u.Surname, ', ',u.FirstName) as 'FullName', u.UserID
FROM user u Where u.FirstName != 'root' AND u.Surname != 'localhost'
ORDER BY u.Surname$$;

