create procedure uspInstallEquipment_Installation(IN serial varchar(24), IN coords varchar(45), IN userID int,
                                                  IN act    bit, IN `desc` varchar(100))
  BEGIN
DECLARE errno INT;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
	GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
	SELECT errno AS MYSQL_ERROR;
	ROLLBACK;
	END;
		
	START TRANSACTION;
    set autocommit=0;
    SELECT e.EquipmentID INTO @ID FROM equipment AS e WHERE e.Serial = `serial`;
    SELECT e.EquipmentCondition INTO @cond FROM equipment AS e WHERE e.EquipmentID = @ID;
    SELECT e.Cost INTO @cost FROM equipment AS e WHERE e.EquipmentID = @ID;
    
    insert into equipmenthistory(`Date`,`Condition`,`Picture`,`Value`,`equipmentID`,`userID`,Active,`Desc`,
                                  AllocationType)
    values(now(),@cond,null,@cost,@ID,userID,act,`desc`,1);
    
    update equipment
    set LocationGps = coords, `Status`=3, UserID=userID
    Where EquipmentID = @ID;
    
    if(act=0)then
    update equipmenthistory set equipmenthistory.Active=act where equipmenthistory.equipmentID=@ID;
    end if;
    
	 IF( row_count() > 0) THEN
		SELECT TRUE;
	END IF;
    
    Commit Work;
END;

