create procedure uspUpdateEquipment_UpdateEquipment(IN id    int, IN eName varchar(45), IN description varchar(45),
                                                    IN brand int, IN section int, IN eType int, IN supplier int)
  BEGIN
	DECLARE errno INT;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
	GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
	SELECT errno AS MYSQL_ERROR;
	ROLLBACK;
	END;
		
	START TRANSACTION;
    SET autocommit=0;
    UPDATE equipment
    SET `Name`=eName, `Desc` = `description`,
    Brand=brand, Section=section,`Type`=`type`,
    `Status`=`status`, Supplier=supplier
    where EquipmentID = id;
    
    IF( row_count() > 0) THEN
		SELECT TRUE;
	ELSEIF (row_count() <=0) then
    SELECT FALSE;
    END IF;
    
    COMMIT WORK;
END;

