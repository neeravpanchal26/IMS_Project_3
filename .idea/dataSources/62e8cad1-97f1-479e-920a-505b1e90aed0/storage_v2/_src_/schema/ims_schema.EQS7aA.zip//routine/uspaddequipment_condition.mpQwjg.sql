create procedure uspAddEquipment_Condition()
  BEGIN 
	SELECT *
    FROM `condition`
    WHERE `condition`.ConditionID != 6;

END;

