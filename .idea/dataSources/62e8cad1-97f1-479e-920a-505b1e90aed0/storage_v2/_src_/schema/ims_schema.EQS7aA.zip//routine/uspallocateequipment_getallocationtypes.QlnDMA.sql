create procedure uspAllocateEquipment_GetAllocationTypes()
  BEGIN
Select *
From AllocationType;
END;

