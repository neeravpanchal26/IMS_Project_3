create procedure uspMaintainEquipmentBySerial_Image(IN equipSerial varchar(24))
  BEGIN
	SELECT EquipmentID INTO @id FROM equipment WHERE equipment.Serial = equipSerial;
    CALL uspAllocateEquipment_GetEquipmentPicture(@id);
END;

