create procedure uspReport_SectionHead_Equipment(IN sDate     varchar(10), IN eDate varchar(10), IN uName varchar(45),
                                                 IN eType     varchar(45), IN eCondition varchar(45),
                                                 IN eStatus   varchar(45), IN eSection varchar(45),
                                                 IN eSupplier varchar(45), IN eBrand varchar(45))
  BEGIN
    SELECT e.EquipmentID,
           e.Name,
           DATE(e.DateReceived) AS DateReceived,
           e.Cost,
           c.ConditionDesc,
           b.BrandDesc,
           s.SectionDesc,
           t.TypeDesc,
           es.StatusDesc,
           esu.Name AS supplier
    FROM equipment AS e,
         `condition` AS c,
         brand AS b,
         section AS s,
         type AS t,
         equipmentstatus AS es,
         user AS u,
         usertype AS ut,
         supplier AS esu
    WHERE e.EquipmentCondition = c.ConditionID
      AND e.Brand = b.BrandID
      AND e.Section = s.SectionID
      AND e.Type = t.TypeID
      AND e.Status = es.StatusID
      AND e.Supplier = esu.supplierID
      AND e.UserID = u.UserID
      AND u.Type = ut.UserTypeID
      AND e.DateReceived BETWEEN sDate AND eDate
      AND c.ConditionDesc LIKE CONCAT(eCondition, '%')
      AND b.BrandDesc LIKE CONCAT(eBrand, '%')
      AND s.SectionDesc LIKE CONCAT(eSection, '%')
      AND t.TypeDesc LIKE CONCAT(eType, '%')
      AND es.StatusDesc LIKE CONCAT(eStatus, '%')
      AND esu.Name LIKE CONCAT(eSupplier, '%')
      AND CONCAT(u.Firstname, ' ', u.Surname, ' - (', ut.UserTypeDesc, ')') LIKE CONCAT(uName, '%');
  END;

