create procedure uspAllocateEquipment_GetEquipmentInfo(IN id int)
  BEGIN
select e.EquipmentID,e.`Name`,`Desc`,Cost, EquipmentCondition,ConditionDesc,Brand,BrandDesc,Section,`Type`,t.TypeDesc,`Status`,StatusDesc,su.`Name` as `Supplier`, DATE_FORMAT(DateReceived,'%Y-%m-%d') as 'DateReceived',Active, `Serial`
from ims_schema.equipment as e,ims_schema.brand b, ims_schema.`condition` c, ims_schema.type t, ims_schema.equipmentstatus es, ims_schema.supplier su
where (b.BrandID = e.Brand and c.ConditionID=e.EquipmentCondition and t.TypeID=e.Type and es.StatusID=e.Status and e.Supplier = su.supplierID) and EquipmentID=id;
end;

