create procedure uspUserSetting_Update(IN userID   int, IN firstName varchar(45), IN lastName varchar(45),
                                       IN dob      varchar(10), IN num varchar(45), IN email varchar(100),
                                       IN address1 varchar(45), IN address2 varchar(45), IN sub int)
  BEGIN
	DECLARE errno INT;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
	GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
	SELECT errno AS MYSQL_ERROR;
	ROLLBACK;
	END;
		
	START TRANSACTION;
    SET autocommit=0;
    
    UPDATE user
	SET
	user.FirstName = firstName,
	user.Surname = lastName,
	user.Dob = dob,
	user.ContactNumber = num,
	user.Email = email,
	user.Address1 = address1,
	user.Address2 = address2,
	user.Suburb = sub
	WHERE user.UserID = userID;
    
	    IF( row_count() > 0) THEN
		SELECT TRUE;
	END IF;
    COMMIT WORK;
END;

