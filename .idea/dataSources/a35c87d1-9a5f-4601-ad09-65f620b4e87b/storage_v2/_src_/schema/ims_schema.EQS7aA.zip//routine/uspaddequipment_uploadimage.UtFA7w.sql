create procedure uspAddEquipment_UploadImage(IN img longblob)
  BEGIN
SELECT MAX(e.EquipmentID) INTO @eMax FROM equipment AS e;
UPDATE equipment SET ConditionPicture = img WHERE equipment.EquipmentID = @eMax;
END;

