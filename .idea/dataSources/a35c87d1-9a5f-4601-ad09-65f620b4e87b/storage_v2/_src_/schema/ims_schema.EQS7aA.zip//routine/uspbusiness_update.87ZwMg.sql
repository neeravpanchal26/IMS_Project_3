create procedure uspBusiness_Update(IN name varchar(45), IN contact varchar(10), IN email varchar(200))
  BEGIN
	DECLARE errno INT;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
	GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
	SELECT errno AS MYSQL_ERROR;
	ROLLBACK;
	END;
    START TRANSACTION;
    SET autocommit=0;
    
    UPDATE business
    SET 
    business.BusinessName = name,
    business.Contact = contact,
    business.Email = email
    WHERE
    business.BusinessID = 1;
    
	COMMIT WORK;
END;

