create procedure uspBusiness_GroupPolicy_Upload(IN pdf longblob)
  BEGIN
    UPDATE business
    SET business.GroupPolicy = pdf
    WHERE business.BusinessID = 1;
END;

