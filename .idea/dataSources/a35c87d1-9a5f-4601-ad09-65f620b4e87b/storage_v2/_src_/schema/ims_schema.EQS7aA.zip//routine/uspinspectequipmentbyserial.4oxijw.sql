create procedure uspInspectEquipmentBySerial(IN equipSerial varchar(24))
  BEGIN
    SELECT EquipmentID INTO @id FROM equipment WHERE equipment.Serial = equipSerial;

	SELECT MAX(equipmenthistory.Date) INTO @dMax FROM equipmenthistory WHERE equipmenthistory.equipmentID = @id AND equipmenthistory.AllocationType = 2;

	SELECT eh.Desc,eh.Value,eh.Condition,e.LocationGps FROM equipment AS e, equipmenthistory AS eh WHERE eh.equipmentID = e.EquipmentID AND eh.Date = @dMax AND e.EquipmentID = @id;
  END;

