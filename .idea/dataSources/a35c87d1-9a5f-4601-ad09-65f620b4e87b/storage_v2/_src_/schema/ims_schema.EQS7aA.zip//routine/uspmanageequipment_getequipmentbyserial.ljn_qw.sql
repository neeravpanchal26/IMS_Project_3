create procedure uspManageEquipment_GetEquipmentBySerial(IN serialNo varchar(24))
  BEGIN
SELECT `Name`, `Desc`
FROM equipment
where `Serial`=serialNo;

END;

