create procedure uspInstallEquipment_InstallEquipmentViaUserID(IN id int)
  BEGIN
SELECT e.`Name`, e.`Serial` 
from equipment e, equipmenthistory eh
where e.EquipmentID = eh.equipmentID and eh.userID = id;
END;

