create procedure uspDashboard_EquipmentExtras(IN days int)
  BEGIN
	SELECT COUNT(equipment.EquipmentID) as 'count',max(DATE(equipment.DateReceived)) as 'DateReceived',equipment.Name,equipment.Desc,equipment.Cost
	FROM equipment
	WHERE equipment.DateReceived  between NOW() + INTERVAL - days DAY AND NOW() + INTERVAL  0 DAY;
END;

