create procedure uspAddEquipment_Brands()
  BEGIN
SELECT BrandID, BrandDesc
FROM brand
Order BY case when BrandDesc = 'Other' then 1 else 0 End, BrandDesc;
END;

