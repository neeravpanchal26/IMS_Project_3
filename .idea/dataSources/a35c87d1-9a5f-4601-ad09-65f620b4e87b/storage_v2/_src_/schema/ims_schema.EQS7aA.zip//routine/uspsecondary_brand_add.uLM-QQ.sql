create procedure uspSecondary_Brand_Add(IN name varchar(45))
  BEGIN
  -- Error Handling
  DECLARE errno INT;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
    SELECT errno AS MYSQL_ERROR;
    ROLLBACK;
  END;

  START TRANSACTION;
  SET autocommit=0;

  SELECT MAX(brand.BrandID)+1 INTO @brandID FROM brand;
  INSERT INTO brand (BrandID, BrandDesc) VALUE (@brandID,name);
  COMMIT WORK;
END;

