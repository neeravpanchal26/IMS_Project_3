create procedure uspDashboard_Users(IN days int)
  BEGIN
	SELECT 
    u.UserID,
	u.FirstName,
    u.Surname, 
	count(lh.UserID) AS count,
    max(lh.LoginDateTime) AS lastAccess
	FROM 
	user AS u,
	loginhistory AS lh

	WHERE 
	lh.UserID = u.UserID AND
	lh.LoginDateTime between NOW() + INTERVAL -days DAY AND NOW() + INTERVAL  0 DAY

	GROUP BY lh.UserID;
END;

