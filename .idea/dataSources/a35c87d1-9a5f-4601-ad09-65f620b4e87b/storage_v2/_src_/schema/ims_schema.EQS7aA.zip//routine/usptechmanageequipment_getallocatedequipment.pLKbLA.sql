create procedure uspTechManageEquipment_GetAllocatedEquipment(IN ID int, IN sDate varchar(10), IN eDate varchar(10))
  BEGIN
SELECT e.`Name`,eh.`Desc`,eh.`Date`, a.TypeDesc,eh.Active
FROM equipment e, equipmenthistory eh, allocationtype a
where 
	e.EquipmentID = eh.equipmentID AND
    eh.AllocationType = a.TypeID AND
    eh.userID=ID AND
    eh.`Date` BETWEEN sDate AND eDate
ORDER BY eh.Active DESC;
END;

