create procedure uspAllocateEquipment_TechnicalEmployees()
  BEGIN
Select CONCAT(user.Firstname,' ',user.Surname,' - (',usertype.UserTypeDesc,')') AS TechEmployee, user.UserID
FROM user,usertype
Where (user.Type!=1 AND user.Active=1) AND user.Type = usertype.UserTypeID;

END;

