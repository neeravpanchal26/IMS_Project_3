create procedure uspAddUser_Suburb(IN city int)
  BEGIN
SELECT *
FROM suburb
WHERE cityID = city;
END;

