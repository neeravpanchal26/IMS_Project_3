create procedure uspUpdateEquipment_UpdateEquipment(IN id      int, IN eName varchar(45), IN description varchar(45),
                                                    IN cost    int, IN equipmentCondition int, IN brand int,
                                                    IN section int, IN eType int, IN dateReceived datetime,
                                                    IN barcode varchar(12), IN supplier int)
  BEGIN
	DECLARE errno INT;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
	GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
	SELECT errno AS MYSQL_ERROR;
	ROLLBACK;
	END;
		
	START TRANSACTION;
    SET autocommit=0;
    
    if ((SELECT COUNT(`Serial`) from equipment where Active=True AND `Serial` = barcode)=0) then
    select true as eActive;
    elseIF((SELECT COUNT(e.`Serial`) FROM equipment AS e WHERE e.Serial = barcode) >= 1) THEN
		SELECT true AS barcodeError;
    else
    UPDATE equipment
    SET `Name`=eName, `Desc` = `description`,Cost=cost,
    EquipmentCondition=equipmentCondition,
    Brand=brand,
    Section=section,`Type`=`type`,
    `Status`=`status`, DateReceived=dateReceived,Supplier=supplier, `Serial`=barcode
    where EquipmentID = id;
    end if;
    
    IF( row_count() > 0) THEN
		SELECT TRUE;
        END IF;
    
    COMMIT WORK;
END;

