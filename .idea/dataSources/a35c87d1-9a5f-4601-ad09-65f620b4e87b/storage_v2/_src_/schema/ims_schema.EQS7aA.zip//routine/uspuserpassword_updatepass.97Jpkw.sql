create procedure uspUserPassword_UpdatePass(IN userID int, IN pWord varchar(50))
  BEGIN
	DECLARE errno INT;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
	GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
	SELECT errno AS MYSQL_ERROR;
	ROLLBACK;
	END;
		
	START TRANSACTION;
    SET autocommit=0;
	SET @salt = UNHEX(SHA1(CONCAT(RAND(), RAND(), RAND())));
	SET @ehash = UNHEX(SHA1(CONCAT(HEX(@salt), pWord)));
    UPDATE user
	SET
	user.Salt = @salt,
	user.Hash = @ehash
	WHERE user.UserID = userID;
    
        IF( row_count() > 0) THEN
		SELECT TRUE;
	END IF;
	COMMIT WORK;
END;

