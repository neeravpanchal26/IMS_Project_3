create procedure uspUpdateEquipment_GetEquipmentDetailsViaID(IN id int)
  BEGIN
SELECT `Name`, `Desc`,LocationGps, Cost, EquipmentCondition,Brand,Section,`Type`,
`Status`, Date(DateReceived) As `DateReceived`,Active, Supplier, `Serial`
FROM ims_schema.equipment
where EquipmentID = id;
END;

