create procedure uspTechManageEquipment_GetAllocatedEquipment(IN ID int)
  BEGIN
SELECT e.`Name`,eh.`Desc`,eh.`Date`, a.TypeDesc
FROM equipment e, equipmenthistory eh, allocationtype a
where e.EquipmentID = eh.equipmentID AND eh.userID=ID AND eh.AllocationType=a.TypeID;
END;

