create procedure uspAddEquipment_Types()
  select t.TypeID, t.TypeDesc
from `type` t;

