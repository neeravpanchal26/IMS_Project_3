create procedure uspAddUser_Create(IN firstName varchar(45), IN lastName varchar(45), IN dob varchar(10),
                                   IN num       varchar(45), IN email varchar(100), IN pword varchar(60), IN uType int,
                                   IN address1  varchar(45), IN address2 varchar(45), IN sub int)
  BEGIN
	-- Error Handling
	DECLARE errno INT;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
	GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
	SELECT errno AS MYSQL_ERROR;
	ROLLBACK;
	END;
		
	START TRANSACTION;
    SET autocommit=0;
	SET @userID = (SELECT MAX(user.UserID)+1 FROM user);
	SET @salt = UNHEX(SHA1(CONCAT(RAND(), RAND(), RAND())));
	SET @ehash = UNHEX(SHA1(CONCAT(HEX(@salt), pword)));
    
    -- Statements Here
    -- If check for duplication
    IF((SELECT COUNT(u.UserID) FROM user AS u WHERE u.Email = email AND u.ContactNumber = num) > 0) THEN
		SELECT true AS bothExists;
	ELSEIF ((SELECT COUNT(u.UserID) FROM user AS u WHERE u.ContactNumber = num) > 0) THEN
		SELECT true AS phoneExists;
    ELSEIF((SELECT COUNT(u.UserID) FROM user AS u WHERE u.Email = email) > 0) THEN
		SELECT true AS emailExists;
	ELSE
		-- Insert Happens if everything is false
		INSERT INTO `ims_schema`.`user`
		(`UserID`,
		`FirstName`,
		`Surname`,
		`Dob`,
		`ContactNumber`,
		`Email`,
		`salt`,
		`Hash`,
		`Type`,
		`Active`,
		`Address1`,
		`Address2`,
		`Suburb`)
		VALUES
		(@userID,firstName,lastName,dob,num,email,@salt,@ehash,uType,0,address1,address2,sub);
	END IF;
    
    IF( row_count() > 0) THEN
		SELECT TRUE;
	END IF;
	
    COMMIT WORK;
END;

