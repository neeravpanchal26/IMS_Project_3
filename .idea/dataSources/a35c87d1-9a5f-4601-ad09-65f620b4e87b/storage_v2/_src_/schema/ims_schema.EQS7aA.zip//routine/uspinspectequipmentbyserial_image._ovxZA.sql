create procedure uspInspectEquipmentBySerial_Image(IN equipSerial varchar(24))
  BEGIN
	SELECT EquipmentID INTO @id FROM equipment WHERE equipment.Serial = equipSerial;

	SELECT MAX(equipmenthistory.Date) INTO @dMax FROM equipmenthistory WHERE equipmenthistory.equipmentID = @id AND equipmenthistory.AllocationType = 2;
    
	SELECT eh.Picture FROM equipmenthistory AS eh WHERE eh.equipmentID = @id AND eh.Date = @dMax;
END;

