create procedure uspVoidUser_Users(IN id int)
  BEGIN
	SELECT 
	u.UserID,CONCAT(u.FirstName,' ',u.Surname) AS info,u.Email,u.Type,u.Active
	FROM user AS u
    WHERE u.UserID NOT IN (id)
    ORDER BY u.Active ASC;
END;

