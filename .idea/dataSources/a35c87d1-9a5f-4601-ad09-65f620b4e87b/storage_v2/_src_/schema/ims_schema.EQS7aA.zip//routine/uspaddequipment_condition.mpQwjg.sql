create procedure uspAddEquipment_Condition()
  SELECT *
FROM `condition`$$;

