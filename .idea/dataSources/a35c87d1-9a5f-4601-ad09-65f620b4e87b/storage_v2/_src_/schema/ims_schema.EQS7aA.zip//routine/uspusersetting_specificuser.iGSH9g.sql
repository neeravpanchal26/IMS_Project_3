create procedure uspUserSetting_SpecificUser(IN id int)
  BEGIN
SELECT u.FirstName,u.Surname,u.Dob,u.ContactNumber,u.Email,u.Address1,u.Address2,u.Suburb,c.CityID
FROM user AS u,city AS c,suburb AS s
WHERE u.UserID = id AND u.Suburb = s.suburbID AND s.CityID = c.cityID;
END;

