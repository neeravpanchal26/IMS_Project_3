create procedure uspDashboard_IndividualUser(IN userID int, IN days int)
  BEGIN
	SELECT 
	u.FirstName,
	count(lh.UserID) AS count,
    DATE(lh.LoginDateTime) AS loginDate
    
	FROM 
	user AS u,
	loginhistory AS lh

	WHERE 
	lh.UserID = u.UserID AND
    lh.UserID = userID AND
	lh.LoginDateTime between NOW() + INTERVAL -days DAY AND NOW() + INTERVAL  0 DAY

	GROUP BY DATE(lh.LoginDateTime);
END;

