create procedure uspMaintainEquipment_Insert(IN userID int, IN eSerial varchar(24), IN eCondition int,
                                             IN eValue decimal, IN eActive bit, IN eDesc varchar(100))
  BEGIN
	DECLARE errno INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
      GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
      SELECT errno AS MYSQL_ERROR;
      ROLLBACK;
    END;

    START TRANSACTION;
    SET autocommit = 0;

    SELECT e.EquipmentID INTO @ID FROM equipment AS e WHERE e.Serial = eSerial;

    INSERT INTO equipmenthistory (`Date`,
                                  `Condition`,
                                  `Value`,
                                  equipmentID,
                                  userID,
                                  Active,
                                  `Desc`,
                                  AllocationType)
    VALUES (NOW(), eCondition, eValue, @ID, userID, eActive, eDesc, 3);

    UPDATE equipment
    SET equipment.EquipmentCondition = eCondition, equipment.Cost = eValue
    WHERE equipment.EquipmentID = @ID;
    
    IF(eActive = 0) THEN
		UPDATE equipmenthistory SET equipmenthistory.Active = eActive WHERE equipmenthistory.equipmentID = @ID AND equipmenthistory.AllocationType = 3;
    END IF;
    IF(eCondition = 6) THEN
		UPDATE equipmenthistory SET equipmenthistory.Active = 0 WHERE equipmenthistory.equipmentID = @ID;
		UPDATE equipment SET equipment.Active = 0 WHERE equipment.equipmentID = @ID;
    END IF;
    
    COMMIT WORK;
    SELECT @id AS equipID;
  END;

