create procedure uspManageEquipment_Active(IN id int, IN act bit)
  BEGIN
	DECLARE errno INT;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
	GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
	SELECT errno AS MYSQL_ERROR;
	ROLLBACK;
	END;
		
	START TRANSACTION;
    SET autocommit=0;
    uPDATE equipment
    set active = act
    where EquipmentID =id;
    COMMIT WORK;
END;

