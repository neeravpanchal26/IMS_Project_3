create procedure uspAddUser_City()
  BEGIN
SELECT *
FROM city;
END;

