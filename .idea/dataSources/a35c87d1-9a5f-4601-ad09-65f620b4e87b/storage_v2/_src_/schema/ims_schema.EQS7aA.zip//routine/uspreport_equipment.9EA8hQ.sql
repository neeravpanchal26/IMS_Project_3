create procedure uspReport_Equipment()
  BEGIN 
    SELECT CONCAT(e.Name,' - (',e.EquipmentID,')') AS equipment
    FROM equipment AS e;
  END;

