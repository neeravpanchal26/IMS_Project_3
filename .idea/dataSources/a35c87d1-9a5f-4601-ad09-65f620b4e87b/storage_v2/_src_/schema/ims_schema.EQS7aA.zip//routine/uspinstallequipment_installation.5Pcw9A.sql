create procedure uspInstallEquipment_Installation(IN serial varchar(24), IN coords varchar(45), IN userID int,
                                                  IN act    bit, IN `desc` varchar(100))
  BEGIN
DECLARE errno INT;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
	GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
	SELECT errno AS MYSQL_ERROR;
	ROLLBACK;
	END;
		
	START TRANSACTION;
    BEGIN
    select @equipID := EquipmentID,@cond := EquipmentCondition, @cost := Cost FROM equipment as e where e.`Serial`=`serial`; 
    
    insert into equipmenthistory(`Date`,`Condition`,`Picture`,`Value`,`equipmentID`,`userID`,Active,`Desc`)
    values(now(),@cond,null,@cost,@equipID,userID,True,act,`desc`);
    
    update equipment
    set LocationGps = coords, `Status`=3, UserID=null
    Where EquipmentID = @equipID;
    Commit work;
    IF( row_count() > 0) THEN
		SELECT TRUE;
	END IF;
    end;
END;

