create procedure uspDashboard_Equipment(IN days int)
  BEGIN
	SELECT COUNT(equipment.EquipmentID) AS count,DATE( equipment.DateReceived) as 'DateReceived'
	FROM equipment
	WHERE equipment.DateReceived  between NOW() + INTERVAL - days DAY AND NOW() + INTERVAL  0 DAY
	GROUP BY equipment.DateReceived;
END;

