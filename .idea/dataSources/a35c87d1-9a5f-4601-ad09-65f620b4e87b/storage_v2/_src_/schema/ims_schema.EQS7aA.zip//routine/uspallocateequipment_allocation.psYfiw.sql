create procedure uspAllocateEquipment_Allocation(IN eID int, IN descr varchar(100), IN userID int, IN alType int)
  BEGIN
DECLARE errno INT;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
	GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
	SELECT errno AS MYSQL_ERROR;
	ROLLBACK;
	END;
    
    START Transaction;
    
    set autocommit=0;
    
    SELECT Cost INTO @eValue FROM equipment Where EquipmentID = eID;
    SELECT EquipmentCondition INTO @eCond FROM equipment Where EquipmentID = eID;
    
    insert into ims_schema.equipmenthistory
    (`Date`,`Condition`,`Picture`,`Value`,`equipmentID`,`userID`,`Active`,`Desc`, AllocationType)
    values(now(),@eCond,null,@eValue,eID, userID, True,descr,alType);
    commit work;
    update ims_schema.equipment
    set equipment.`Status` = "1", equipment.UserID=userID
    where equipment.EquipmentID = eID;
    IF( row_count() > 0) THEN
		SELECT TRUE;
	END IF;
    commit work;
END;

