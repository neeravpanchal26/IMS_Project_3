create procedure uspLogin_Check(IN uEmail varchar(100), IN pWord varchar(50))
  BEGIN
	SELECT  user.UserID,user.Email,user.Salt,user.Type INTO @id,@email,@salt,@type FROM user WHERE user.Email = uEmail;
    IF (SELECT COUNT(user.UserID) FROM user WHERE user.Email = uEmail AND user.Hash = UNHEX(SHA1(CONCAT(HEX(@salt), pWord)))) != 1 THEN
		SELECT false;
    ELSE
		SELECT user.Active,CONCAT(user.FirstName,' ',user.SurName,' - (',usertype.UserTypeDesc,')') AS username,user.UserID,usertype.UserTypeID,usertype.UserTypeDesc FROM user,usertype WHERE user.UserID = @id AND usertype.UserTypeID = @type;
        IF (SELECT user.Active FROM user WHERE user.UserID = @id) = 1 THEN
			INSERT INTO loginhistory (UserID,LoginDateTime) VALUES (@id,NOW());
        END IF;
    END IF;
END;

