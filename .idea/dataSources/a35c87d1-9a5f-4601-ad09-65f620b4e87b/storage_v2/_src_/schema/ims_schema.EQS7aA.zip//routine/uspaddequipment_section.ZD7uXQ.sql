create procedure uspAddEquipment_Section()
  BEGIN
select *
from section;
END;

