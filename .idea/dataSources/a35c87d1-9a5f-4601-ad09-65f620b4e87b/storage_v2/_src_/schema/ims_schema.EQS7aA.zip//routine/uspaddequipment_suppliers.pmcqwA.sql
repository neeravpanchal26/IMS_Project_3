create procedure uspAddEquipment_Suppliers()
  BEGIN
select *
from supplier;
END;

