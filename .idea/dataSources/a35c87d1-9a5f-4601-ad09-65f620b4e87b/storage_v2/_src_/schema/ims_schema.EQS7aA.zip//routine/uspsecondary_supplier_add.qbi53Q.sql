create procedure uspSecondary_Supplier_Add(IN supplierName varchar(45), IN supplierNumber varchar(10),
                                           IN email        varchar(100))
  BEGIN
	 -- Error Handling
	  DECLARE errno INT;
	  DECLARE EXIT HANDLER FOR SQLEXCEPTION
	  BEGIN
		GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
		SELECT errno AS MYSQL_ERROR;
		ROLLBACK;
	  END;

	  START TRANSACTION;
	  SET autocommit=0;
      
      SELECT MAX(supplierID)+1 INTO @id FROM supplier;
      INSERT INTO `ims_schema`.`supplier`
(`supplierID`,
`Name`,
`ContactNumber`,
`Email`)
VALUES
(@id,
supplierName,
supplierNumber,
email);
      COMMIT WORK;
END;

