create procedure uspAllocateEquipment_GetEquipmentPicture(IN id int)
  BEGIN
Select ConditionPicture
FROM equipment
Where EquipmentID=id;
END;

