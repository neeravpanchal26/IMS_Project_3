create procedure uspManageEquipment_GetEquipmentInfo()
  BEGIN
SELECT 
	distinct e.EquipmentID,
    e.Name,
    e.`Desc`,
    LocationGps,
    e.Cost,
    e.EquipmentCondition,
    c.ConditionDesc,
    e.Brand,
    b.BrandDesc,
    e.Section,s.SectionDesc,
    e.Type,
    e.Status,
    e.Active,
    Supplier,
    `Serial`,
    StatusDesc as StatusDescription,
    DateReceived
FROM ims_schema.equipment as e, ims_schema.`condition` as c, ims_schema.brand as b, ims_schema.section as s, ims_schema.equipmentstatus as es, ims_schema.user as u
where e.EquipmentCondition=c.ConditionID and b.BrandID = e.Brand and e.Status=es.StatusID and s.SectionID=e.Section
Order by e.DateReceived DESC;END;

