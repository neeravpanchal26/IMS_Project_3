create procedure uspSecondary_City_Add(IN name varchar(45))
  BEGIN
  -- Error Handling
  DECLARE errno INT;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
    SELECT errno AS MYSQL_ERROR;
    ROLLBACK;
  END;

  START TRANSACTION;
  SET autocommit=0;

  SELECT MAX(city.cityID)+1 INTO @cityID FROM city;
  INSERT INTO city (cityID, cityName) VALUE (@cityID,name);
  COMMIT WORK;
END;

