create procedure uspUpdateEquipment_GetEquipmentImageViaID(IN id int)
  BEGIN
select ConditionPicture
from equipment
where EquipmentID=id;
END;

