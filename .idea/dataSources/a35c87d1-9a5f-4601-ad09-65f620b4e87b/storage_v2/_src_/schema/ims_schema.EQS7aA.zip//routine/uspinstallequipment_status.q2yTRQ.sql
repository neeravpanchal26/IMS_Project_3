create procedure uspInstallEquipment_Status()
  BEGIN
	SELECT ehs.StatusID,ehs.StatusDesc
    FROM equipmenthistorystatus AS ehs
    ORDER BY ehs.StatusID DESC;
END;

