create procedure uspUserPassword_OldCheck(IN userID int, IN pWord varchar(50))
  BEGIN
	SELECT user.Salt INTO @salt
    FROM user
    WHERE user.UserID = userID;
    IF(SELECT COUNT(user.UserID) FROM user WHERE user.UserID = userID AND user.Hash = UNHEX(SHA1(CONCAT(HEX(@salt), pWord)))) != 1 THEN
		SELECT false AS result;
	ELSE
		SELECT true AS result;
	END IF;
END;

