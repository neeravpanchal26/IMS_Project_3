create procedure uspVoidUser_Status(IN ID int, IN STA int)
  BEGIN
	DECLARE errno INT;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
	GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
	SELECT errno AS MYSQL_ERROR;
	ROLLBACK;
	END;
    
	START TRANSACTION;
    SET autocommit=0;
    UPDATE user
    SET user.Active = STA
    WHERE user.UserID = ID;
    
    IF( row_count() > 0) THEN
		SELECT TRUE;
	END IF;
    
    COMMIT WORK;
    
    
END;

